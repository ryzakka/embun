import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../data/asset_catalog.dart';

const _placeholder = ColoredBox(color: Color(0x33000000));

class GameImage extends StatelessWidget {
  final String? path;
  final BoxFit fit;
  final Alignment alignment;
  final int? cacheWidth;
  const GameImage({
    super.key,
    required this.path,
    this.fit = BoxFit.cover,
    this.alignment = Alignment.center,
    this.cacheWidth,
  });

  @override
  Widget build(BuildContext context) {
    final p = path;
    if (p == null) return _placeholder;
    return Image.asset(
      p,
      fit: fit,
      alignment: alignment,
      cacheWidth: cacheWidth,
      gaplessPlayback: true,
      errorBuilder: (_, _, _) => _placeholder,
    );
  }
}

/// Gambar yang mengisi bidang tempatnya dipasang, diputar seperempat putaran
/// bila BIDANG ITU berbentuk potret (tinggi > lebar), supaya sisi panjang
/// gambar mengikuti sisi panjang bidang. Yang diukur adalah bidang gambarnya
/// sendiri (batas dari induk), bukan layar atau perangkat. Bidang landscape
/// atau persegi: gambar apa adanya. [rotateWhenTall] false = tak pernah diputar.
class OrientedImage extends StatelessWidget {
  final String? path;
  final int? cacheWidth;
  final bool rotateWhenTall;
  const OrientedImage({
    super.key,
    required this.path,
    this.cacheWidth,
    this.rotateWhenTall = true,
  });

  @override
  Widget build(BuildContext context) {
    final img = GameImage(path: path, cacheWidth: cacheWidth);
    if (!rotateWhenTall) return img;
    return LayoutBuilder(builder: (context, c) {
      final tall = c.hasBoundedWidth &&
          c.hasBoundedHeight &&
          c.maxHeight > c.maxWidth;
      return tall ? RotatedBox(quarterTurns: 1, child: img) : img;
    });
  }
}

Widget _fadeLayout(Widget? current, List<Widget> previous) => Stack(
  fit: StackFit.expand,
  children: [...previous, ?current],
);

/// Latar bentangan yang memudar saat gambar berganti.
class Backdrop extends StatelessWidget {
  final String? path;
  final bool dark;
  final double dim;
  const Backdrop({
    super.key,
    required this.path,
    this.dark = false,
    this.dim = 0.7,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 1200),
          layoutBuilder: _fadeLayout,
          child: GameImage(key: ValueKey(path), path: path, cacheWidth: 1280),
        ),
        ColoredBox(
          color: (dark ? const Color(0xFF1A1030) : const Color(0xFF07130F))
              .withValues(alpha: dim),
        ),
      ],
    );
  }
}

/// Sosok yang menampakkan diri pelan-pelan di atas latar, lalu lenyap; tiap
/// putaran berganti ke gambar berikutnya dari [paths]. Tidak menerima sentuhan.
class Apparition extends StatefulWidget {
  final List<String> paths;
  final double peak; // opasitas tertinggi (0..1)
  final Duration cycle;
  const Apparition({
    super.key,
    required this.paths,
    this.peak = 0.55,
    this.cycle = const Duration(seconds: 9),
  });

  @override
  State<Apparition> createState() => _ApparitionState();
}

class _ApparitionState extends State<Apparition>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
  AnimationController(vsync: this, duration: widget.cycle);
  int _i = 0;

  @override
  void initState() {
    super.initState();
    _c.addStatusListener((st) {
      if (st == AnimationStatus.completed && mounted) {
        setState(() => _i = (_i + 1) % widget.paths.length);
        _c.forward(from: 0);
      }
    });
    // Jeda sebentar supaya lembah terlihat sepi dulu.
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (mounted) _c.forward();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.paths.isEmpty) return const SizedBox.shrink();
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, _) {
          final t = _c.value;
          final bell = math.pow(math.sin(math.pi * t), 2).toDouble();
          final flicker = 0.92 + 0.08 * math.sin(t * 90);
          return Opacity(
            opacity: (widget.peak * bell * flicker).clamp(0.0, 1.0).toDouble(),
            child: Transform.scale(
              scale: 1.04 + 0.06 * t,
              child: GameImage(
                  key: ValueKey(_i),
                  path: widget.paths[_i],
                  cacheWidth: 1280),
            ),
          );
        },
      ),
    );
  }
}

/// Potret pohon 16:9, menyesuaikan ruang yang tersedia.
class TreePortrait extends StatelessWidget {
  final int leaves;
  final String? pathOverride;
  const TreePortrait({super.key, required this.leaves, this.pathOverride});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      var w = c.maxWidth.isFinite ? c.maxWidth : 640.0;
      if (w > 640) w = 640;
      var h = w * 9 / 16;
      if (c.maxHeight.isFinite && h > c.maxHeight) {
        h = c.maxHeight;
        w = h * 16 / 9;
      }
      final path = pathOverride ?? treePath(leaves);
      return Center(
        child: SizedBox(
          width: w,
          height: h,
          child: DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white24),
              boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 18)],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 900),
                layoutBuilder: _fadeLayout,
                child: GameImage(key: ValueKey(path), path: path, cacheWidth: 1000),
              ),
            ),
          ),
        ),
      );
    });
  }
}

/// Avatar bulat dari bagian atas kartu karakter.
class PlayerAvatar extends StatelessWidget {
  final String? path;
  final double size;
  final Color ring;

  /// 'subur' atau 'layu': karangan daun melingkari avatar (bingkai-subur /
  /// bingkai-layu di assets/bentang). Widget jadi ~1,45x lebih besar. Null =
  /// tanpa karangan.
  final String? wreath;
  const PlayerAvatar({
    super.key,
    required this.path,
    this.size = 40,
    this.ring = Colors.white38,
    this.wreath,
  });

  @override
  Widget build(BuildContext context) {
    final core = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: ring, width: 2),
      ),
      child: ClipOval(
        child: path == null
            ? GameIcon('character', size: size * 0.8)
            : (path!.startsWith(protagonisDir) ||
            path!.startsWith(antagonisDir))
            ? _FaceCrop(path: path!, size: size)
            : GameImage(
          path: path,
          alignment: const Alignment(0, -0.6),
          cacheWidth: (size * 3).round(),
        ),
      ),
    );
    final w = wreath;
    final wp = w == null ? null : sceneryPath('bingkai-$w');
    if (wp == null) return core;
    final outer = size * 1.45;
    return SizedBox(
      width: outer,
      height: outer,
      child: Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: [
          core,
          IgnorePointer(
            child: SizedBox(
              width: outer,
              height: outer,
              child: GameImage(
                  path: wp, fit: BoxFit.contain, cacheWidth: (outer * 2).round()),
            ),
          ),
        ],
      ),
    );
  }
}

/// Potongan wajah dari kartu karakter 2:3 (protagonis dan kartu gelap): kartu
/// diperbesar ke arah wajah
/// (sekitar 27% dari atas) sehingga bingkai berhias dan plat nama tidak ikut
/// tampak di avatar bulat.
class _FaceCrop extends StatelessWidget {
  final String path;
  final double size;
  const _FaceCrop({required this.path, required this.size});

  static const _windowW = 0.62; // lebar jendela = 62% lebar kartu
  static const _faceY = 0.27; // pusat wajah dari atas kartu

  @override
  Widget build(BuildContext context) {
    final cw = size / _windowW;
    final ch = cw * kProtagonistAspect;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.hardEdge,
        children: [
          Positioned(
            left: (size - cw) / 2,
            top: size / 2 - _faceY * ch,
            width: cw,
            height: ch,
            child: GameImage(path: path, cacheWidth: (cw * 2).round()),
          ),
        ],
      ),
    );
  }
}

/// Kartu karakter potret. Rasio mengikuti jenis kartu ([cardAspectFor]):
/// protagonis dan kartu gelap sama-sama 2:3.
class CardArt extends StatelessWidget {
  final String? path;
  final double width;
  final Color? glow;
  const CardArt({super.key, required this.path, this.width = 100, this.glow});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: width * cardAspectFor(path),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: (glow ?? Colors.black).withValues(alpha: 0.55),
            blurRadius: glow == null ? 8 : 26,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: GameImage(path: path, cacheWidth: (width * 2).round()),
      ),
    );
  }
}

/// Ikon emas-hijau dari assets/ikon. Untuk ikon persegi cukup isi [size].
/// Untuk gambar lebar (cap, judul) isi [width] dan [height].
class GameIcon extends StatelessWidget {
  final String name;
  final double size;
  final double? width;
  final double? height;
  const GameIcon(this.name,
      {super.key, this.size = 20, this.width, this.height});

  @override
  Widget build(BuildContext context) {
    final w = width ?? size;
    final h = height ?? size;
    final p = ikonPath(name);
    return SizedBox(
      width: w,
      height: h,
      child: p == null
          ? null
          : GameImage(path: p, fit: BoxFit.contain, cacheWidth: (w * 3).round()),
    );
  }
}
/// Layar muat: ikon aplikasi berdenyut pelan di atas indikator tipis.
class EmbunLoading extends StatefulWidget {
  final String? text;
  const EmbunLoading({super.key, this.text});

  @override
  State<EmbunLoading> createState() => _EmbunLoadingState();
}

class _EmbunLoadingState extends State<EmbunLoading>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1400))
    ..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedBuilder(
          animation: _c,
          builder: (_, child) {
            final t = Curves.easeInOut.transform(_c.value);
            return Opacity(
              opacity: 0.7 + 0.3 * t,
              child: Transform.scale(scale: 0.96 + 0.06 * t, child: child),
            );
          },
          child: SizedBox(
            width: 96,
            height: 96,
            child: GameImage(
                path: logoPath('ikonapp-transparent'),
                fit: BoxFit.contain,
                cacheWidth: 288),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: 120,
          child: LinearProgressIndicator(
              minHeight: 3, borderRadius: BorderRadius.circular(2)),
        ),
        if (widget.text != null) ...[
          const SizedBox(height: 10),
          Text(widget.text!,
              style: const TextStyle(fontSize: 12, color: Colors.white60)),
        ],
      ],
    ),
  );
}